/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.eodeco.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.eodeco.EoDecoMod;

@EventBusSubscriber
public class EoDecoModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, EoDecoMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> EXTRA_ORE_DECORATION_DLC = REGISTRY.register("extra_ore_decoration_dlc",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.eo_deco.extra_ore_decoration_dlc")).icon(() -> new ItemStack(EoDecoModItems.JUST_FOR_CREATIVE_TAB.get())).displayItems((parameters, tabData) -> {
				tabData.accept(EoDecoModBlocks.PALLADIUM_LANTERN.get().asItem());
				tabData.accept(EoDecoModBlocks.SAPPHIRE_LANTERN.get().asItem());
				tabData.accept(EoDecoModBlocks.RUBY_LANTERN.get().asItem());
				tabData.accept(EoDecoModBlocks.PALLADIUM_BLOC.get().asItem());
				tabData.accept(EoDecoModBlocks.RUBY_BLOC.get().asItem());
				tabData.accept(EoDecoModBlocks.URANIUM_BLOC_0.get().asItem());
				tabData.accept(EoDecoModBlocks.URANIUM_BLOC_1.get().asItem());
				tabData.accept(EoDecoModBlocks.SAPPHIRE_BLOC.get().asItem());
			}).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(EoDecoModBlocks.PALLADIUM_LANTERN.get().asItem());
			tabData.accept(EoDecoModBlocks.SAPPHIRE_LANTERN.get().asItem());
			tabData.accept(EoDecoModBlocks.RUBY_LANTERN.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(EoDecoModBlocks.PALLADIUM_BLOC.get().asItem());
			tabData.accept(EoDecoModBlocks.RUBY_BLOC.get().asItem());
			tabData.accept(EoDecoModBlocks.URANIUM_BLOC_0.get().asItem());
			tabData.accept(EoDecoModBlocks.URANIUM_BLOC_1.get().asItem());
			tabData.accept(EoDecoModBlocks.SAPPHIRE_BLOC.get().asItem());
		}
	}
}