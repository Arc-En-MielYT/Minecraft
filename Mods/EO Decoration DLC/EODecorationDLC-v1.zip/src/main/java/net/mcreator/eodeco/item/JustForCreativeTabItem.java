package net.mcreator.eodeco.item;

import net.minecraft.world.item.Item;

public class JustForCreativeTabItem extends Item {
	public JustForCreativeTabItem(Item.Properties properties) {
		super(properties);
	}
}