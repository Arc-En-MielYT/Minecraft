/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.eodeco.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.eodeco.item.JustForCreativeTabItem;
import net.mcreator.eodeco.EoDecoMod;

import java.util.function.Function;

public class EoDecoModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(EoDecoMod.MODID);
	public static final DeferredItem<Item> PALLADIUM_LANTERN;
	public static final DeferredItem<Item> SAPPHIRE_LANTERN;
	public static final DeferredItem<Item> RUBY_LANTERN;
	public static final DeferredItem<Item> JUST_FOR_CREATIVE_TAB;
	public static final DeferredItem<Item> PALLADIUM_BLOC;
	public static final DeferredItem<Item> RUBY_BLOC;
	public static final DeferredItem<Item> URANIUM_BLOC_0;
	public static final DeferredItem<Item> URANIUM_BLOC_1;
	public static final DeferredItem<Item> SAPPHIRE_BLOC;
	static {
		PALLADIUM_LANTERN = block(EoDecoModBlocks.PALLADIUM_LANTERN);
		SAPPHIRE_LANTERN = block(EoDecoModBlocks.SAPPHIRE_LANTERN);
		RUBY_LANTERN = block(EoDecoModBlocks.RUBY_LANTERN);
		JUST_FOR_CREATIVE_TAB = register("just_for_creative_tab", JustForCreativeTabItem::new);
		PALLADIUM_BLOC = block(EoDecoModBlocks.PALLADIUM_BLOC);
		RUBY_BLOC = block(EoDecoModBlocks.RUBY_BLOC);
		URANIUM_BLOC_0 = block(EoDecoModBlocks.URANIUM_BLOC_0);
		URANIUM_BLOC_1 = block(EoDecoModBlocks.URANIUM_BLOC_1);
		SAPPHIRE_BLOC = block(EoDecoModBlocks.SAPPHIRE_BLOC);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, Item.Properties::new);
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), () -> properties);
	}
}