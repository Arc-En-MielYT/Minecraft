/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.eodeco.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.eodeco.block.*;
import net.mcreator.eodeco.EoDecoMod;

import java.util.function.Function;

public class EoDecoModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(EoDecoMod.MODID);
	public static final DeferredBlock<Block> PALLADIUM_LANTERN;
	public static final DeferredBlock<Block> SAPPHIRE_LANTERN;
	public static final DeferredBlock<Block> RUBY_LANTERN;
	public static final DeferredBlock<Block> PALLADIUM_BLOC;
	public static final DeferredBlock<Block> RUBY_BLOC;
	public static final DeferredBlock<Block> URANIUM_BLOC_0;
	public static final DeferredBlock<Block> URANIUM_BLOC_1;
	public static final DeferredBlock<Block> SAPPHIRE_BLOC;
	static {
		PALLADIUM_LANTERN = register("palladium_lantern", PalladiumLanternBlock::new);
		SAPPHIRE_LANTERN = register("sapphire_lantern", SapphireLanternBlock::new);
		RUBY_LANTERN = register("ruby_lantern", RubyLanternBlock::new);
		PALLADIUM_BLOC = register("palladium_bloc", PalladiumBlocBlock::new);
		RUBY_BLOC = register("ruby_bloc", RubyBlocBlock::new);
		URANIUM_BLOC_0 = register("uranium_bloc_0", UraniumBloc0Block::new);
		URANIUM_BLOC_1 = register("uranium_bloc_1", UraniumBloc1Block::new);
		SAPPHIRE_BLOC = register("sapphire_bloc", SapphireBlocBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}