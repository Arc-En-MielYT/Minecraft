/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.extraore.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.extraore.ExtraOreMod;

@EventBusSubscriber
public class ExtraOreModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ExtraOreMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> EXTRA_ORE = REGISTRY.register("extra_ore",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.extra_ore.extra_ore")).icon(() -> new ItemStack(ExtraOreModBlocks.RUBY_ORE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(ExtraOreModBlocks.RUBY_ORE.get().asItem());
				tabData.accept(ExtraOreModItems.RUBY.get());
				tabData.accept(ExtraOreModBlocks.PALLADIUM_ORE.get().asItem());
				tabData.accept(ExtraOreModItems.PALLADIUM_INGOT.get());
				tabData.accept(ExtraOreModItems.RUBY_SWORD.get());
				tabData.accept(ExtraOreModItems.RUBY_SHOVEL.get());
				tabData.accept(ExtraOreModItems.RUBY_PICKAXE.get());
				tabData.accept(ExtraOreModItems.RUBY_AXE.get());
				tabData.accept(ExtraOreModItems.RUBY_HOE.get());
				tabData.accept(ExtraOreModItems.PALLADIUM_SWORD.get());
				tabData.accept(ExtraOreModItems.PALLADIUM_SHOVEL.get());
				tabData.accept(ExtraOreModItems.PALLADIUM_PICKAXE.get());
				tabData.accept(ExtraOreModItems.PALLADIUM_AXE.get());
				tabData.accept(ExtraOreModItems.PALLADIUM_HOE.get());
			}).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(ExtraOreModBlocks.RUBY_ORE.get().asItem());
			tabData.accept(ExtraOreModBlocks.PALLADIUM_ORE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(ExtraOreModItems.RUBY.get());
			tabData.accept(ExtraOreModItems.PALLADIUM_INGOT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(ExtraOreModItems.RUBY_SWORD.get());
			tabData.accept(ExtraOreModItems.RUBY_AXE.get());
			tabData.accept(ExtraOreModItems.PALLADIUM_SWORD.get());
			tabData.accept(ExtraOreModItems.PALLADIUM_AXE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(ExtraOreModItems.RUBY_SHOVEL.get());
			tabData.accept(ExtraOreModItems.RUBY_PICKAXE.get());
			tabData.accept(ExtraOreModItems.RUBY_HOE.get());
			tabData.accept(ExtraOreModItems.PALLADIUM_SHOVEL.get());
			tabData.accept(ExtraOreModItems.PALLADIUM_PICKAXE.get());
			tabData.accept(ExtraOreModItems.PALLADIUM_HOE.get());
		}
	}
}