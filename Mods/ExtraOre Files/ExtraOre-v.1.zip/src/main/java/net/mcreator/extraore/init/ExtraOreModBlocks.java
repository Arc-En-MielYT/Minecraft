/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.extraore.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.extraore.block.RubyOreBlock;
import net.mcreator.extraore.block.PalladiumOreBlock;
import net.mcreator.extraore.ExtraOreMod;

import java.util.function.Function;

public class ExtraOreModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(ExtraOreMod.MODID);
	public static final DeferredBlock<Block> RUBY_ORE;
	public static final DeferredBlock<Block> PALLADIUM_ORE;
	static {
		RUBY_ORE = register("ruby_ore", RubyOreBlock::new);
		PALLADIUM_ORE = register("palladium_ore", PalladiumOreBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}