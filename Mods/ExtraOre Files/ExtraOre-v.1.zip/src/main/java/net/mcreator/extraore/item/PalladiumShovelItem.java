package net.mcreator.extraore.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class PalladiumShovelItem extends ShovelItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 230, 7f, 0, 15, TagKey.create(Registries.ITEM, Identifier.parse("extra_ore:palladium_shovel_repair_items")));

	public PalladiumShovelItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 3.25f, -2.8f, properties);
	}
}