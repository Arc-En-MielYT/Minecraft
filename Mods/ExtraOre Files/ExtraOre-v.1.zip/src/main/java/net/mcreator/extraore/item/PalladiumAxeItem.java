package net.mcreator.extraore.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class PalladiumAxeItem extends AxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 100, 7f, 0, 2, TagKey.create(Registries.ITEM, Identifier.parse("extra_ore:palladium_axe_repair_items")));

	public PalladiumAxeItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 10f, -3.1f, properties);
	}
}