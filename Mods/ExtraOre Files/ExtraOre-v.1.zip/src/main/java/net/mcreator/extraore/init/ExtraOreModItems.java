/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.extraore.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.extraore.item.*;
import net.mcreator.extraore.ExtraOreMod;

import java.util.function.Function;

public class ExtraOreModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(ExtraOreMod.MODID);
	public static final DeferredItem<Item> RUBY_ORE;
	public static final DeferredItem<Item> RUBY;
	public static final DeferredItem<Item> PALLADIUM_ORE;
	public static final DeferredItem<Item> PALLADIUM_INGOT;
	public static final DeferredItem<Item> RUBY_SWORD;
	public static final DeferredItem<Item> RUBY_SHOVEL;
	public static final DeferredItem<Item> RUBY_PICKAXE;
	public static final DeferredItem<Item> RUBY_AXE;
	public static final DeferredItem<Item> RUBY_HOE;
	public static final DeferredItem<Item> PALLADIUM_SWORD;
	public static final DeferredItem<Item> PALLADIUM_SHOVEL;
	public static final DeferredItem<Item> PALLADIUM_PICKAXE;
	public static final DeferredItem<Item> PALLADIUM_AXE;
	public static final DeferredItem<Item> PALLADIUM_HOE;
	static {
		RUBY_ORE = block(ExtraOreModBlocks.RUBY_ORE);
		RUBY = register("ruby", RubyItem::new);
		PALLADIUM_ORE = block(ExtraOreModBlocks.PALLADIUM_ORE);
		PALLADIUM_INGOT = register("palladium_ingot", PalladiumIngotItem::new);
		RUBY_SWORD = register("ruby_sword", RubySwordItem::new);
		RUBY_SHOVEL = register("ruby_shovel", RubyShovelItem::new);
		RUBY_PICKAXE = register("ruby_pickaxe", RubyPickaxeItem::new);
		RUBY_AXE = register("ruby_axe", RubyAxeItem::new);
		RUBY_HOE = register("ruby_hoe", RubyHoeItem::new);
		PALLADIUM_SWORD = register("palladium_sword", PalladiumSwordItem::new);
		PALLADIUM_SHOVEL = register("palladium_shovel", PalladiumShovelItem::new);
		PALLADIUM_PICKAXE = register("palladium_pickaxe", PalladiumPickaxeItem::new);
		PALLADIUM_AXE = register("palladium_axe", PalladiumAxeItem::new);
		PALLADIUM_HOE = register("palladium_hoe", PalladiumHoeItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, Item.Properties::new);
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), () -> properties);
	}
}