package net.mcreator.extraore.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class RubyShovelItem extends ShovelItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 300, 7f, 0, 15, TagKey.create(Registries.ITEM, Identifier.parse("extra_ore:ruby_shovel_repair_items")));

	public RubyShovelItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 2.25f, -2.8f, properties);
	}
}