package net.mcreator.extraore.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class RubyOreBlock extends Block {
	public RubyOreBlock(BlockBehaviour.Properties properties) {
		super(properties.strength(5f, 3f).requiresCorrectToolForDrops());
	}
}