package net.mcreator.extraore.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class PalladiumOreBlock extends Block {
	public PalladiumOreBlock(BlockBehaviour.Properties properties) {
		super(properties.strength(5f, 3f).requiresCorrectToolForDrops());
	}
}