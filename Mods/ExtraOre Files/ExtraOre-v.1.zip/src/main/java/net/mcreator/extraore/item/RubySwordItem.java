package net.mcreator.extraore.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class RubySwordItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 100, 7f, 0, 15, TagKey.create(Registries.ITEM, Identifier.parse("extra_ore:ruby_sword_repair_items")));

	public RubySwordItem(Item.Properties properties) {
		super(properties.sword(TOOL_MATERIAL, 3f, -2.4f));
	}
}