package net.mcreator.extraore.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.HoeItem;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class RubyHoeItem extends HoeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 300, 7f, 0, 15, TagKey.create(Registries.ITEM, Identifier.parse("extra_ore:ruby_hoe_repair_items")));

	public RubyHoeItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 1f, -1f, properties);
	}
}