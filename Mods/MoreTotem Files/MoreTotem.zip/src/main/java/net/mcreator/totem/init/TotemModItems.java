/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.totem.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;

import net.minecraft.world.item.Item;

import net.mcreator.totem.item.*;
import net.mcreator.totem.TotemMod;

import java.util.function.Function;

public class TotemModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(TotemMod.MODID);
	public static final DeferredItem<Item> COAL_TOTEM;
	public static final DeferredItem<Item> IRON_TOTEM;
	public static final DeferredItem<Item> GOLD_TOTEM;
	public static final DeferredItem<Item> DIAMOND_TOTEM;
	public static final DeferredItem<Item> NETHERITE_TOTEM;
	public static final DeferredItem<Item> ULTIMATE_TOTEM;
	public static final DeferredItem<Item> USED_ULTIMATE_TOTEM;
	static {
		COAL_TOTEM = register("coal_totem", CoalTotemItem::new);
		IRON_TOTEM = register("iron_totem", IronTotemItem::new);
		GOLD_TOTEM = register("gold_totem", GoldTotemItem::new);
		DIAMOND_TOTEM = register("diamond_totem", DiamondTotemItem::new);
		NETHERITE_TOTEM = register("netherite_totem", NetheriteTotemItem::new);
		ULTIMATE_TOTEM = register("ultimate_totem", UltimateTotemItem::new);
		USED_ULTIMATE_TOTEM = register("used_ultimate_totem", UsedUltimateTotemItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, Item.Properties::new);
	}
}