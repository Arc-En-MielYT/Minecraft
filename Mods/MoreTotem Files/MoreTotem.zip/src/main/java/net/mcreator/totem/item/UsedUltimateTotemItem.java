package net.mcreator.totem.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class UsedUltimateTotemItem extends Item {
	public UsedUltimateTotemItem(Item.Properties properties) {
		super(properties.rarity(Rarity.EPIC).stacksTo(1).fireResistant());
	}
}