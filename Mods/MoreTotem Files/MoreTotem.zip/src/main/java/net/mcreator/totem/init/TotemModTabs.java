/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.totem.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.totem.TotemMod;

public class TotemModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, TotemMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MORE_TOTEM = REGISTRY.register("more_totem",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.totem.more_totem")).icon(() -> new ItemStack(TotemModItems.COAL_TOTEM.get())).displayItems((parameters, tabData) -> {
				tabData.accept(TotemModItems.COAL_TOTEM.get());
				tabData.accept(TotemModItems.IRON_TOTEM.get());
				tabData.accept(TotemModItems.GOLD_TOTEM.get());
				tabData.accept(TotemModItems.DIAMOND_TOTEM.get());
				tabData.accept(TotemModItems.NETHERITE_TOTEM.get());
				tabData.accept(TotemModItems.ULTIMATE_TOTEM.get());
				tabData.accept(TotemModItems.USED_ULTIMATE_TOTEM.get());
			}).withSearchBar().build());
}