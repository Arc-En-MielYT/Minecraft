package net.mcreator.totem.item;

import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.ItemInstance;
import net.minecraft.world.item.Item;

public class CoalTotemItem extends Item {
	public CoalTotemItem(Item.Properties properties) {
		super(properties.stacksTo(1));
	}

	@Override
	public ItemStackTemplate getCraftingRemainder(ItemInstance itemInstance) {
		return new ItemStackTemplate(this);
	}
}